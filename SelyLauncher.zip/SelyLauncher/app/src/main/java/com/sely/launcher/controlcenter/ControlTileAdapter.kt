package com.sely.launcher.controlcenter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.sely.launcher.R

class ControlTileAdapter(
    private val context: Context,
    private val tiles: List<ControlTile>,
    // Opt-in only: defaults to false, so Command Center, Game Mode and
    // Sidebar — which also use this adapter — render exactly as before.
    // Only ControlCenterActivity passes true, for the iOS-card redesign.
    private val iosStyle: Boolean = false
) : RecyclerView.Adapter<ControlTileAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.tileIcon)
        val label: TextView = view.findViewById(R.id.tileLabel)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(context).inflate(R.layout.item_tile, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount() = tiles.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val tile = tiles[position]
        holder.icon.setImageResource(tile.iconRes)
        holder.icon.setColorFilter(com.sely.launcher.theme.ThemeManager.accentColor(context))
        holder.label.text = tile.label
        holder.label.setTextColor(com.sely.launcher.theme.ThemeManager.textPrimary(context))
        if (iosStyle) {
            com.sely.launcher.theme.ThemeManager.applyIosInset(holder.itemView, 16f)
        }
        holder.itemView.setOnClickListener { tile.onClick() }
    }
}
